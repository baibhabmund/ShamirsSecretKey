import java.io.*;
import java.util.*;

public class SecretPolynomialSolver {

    static class Point {
        int x;
        long y;

        Point(int x, long y) {
            this.x = x;
            this.y = y;
        }
    }

    // Convert string of given base to decimal
    public static long baseToDecimal(String value, int base) {
        long result = 0;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            int digit = Character.isDigit(c) ? c - '0' : (c - 'a' + 10);
            result = result * base + digit;
        }
        return result;
    }

    // Read test case and return list of Points
    public static List<Point> parseJsonRoots(String filename, int k) throws Exception {
        List<Point> roots = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(filename));
        String line;
        boolean readRoots = false;
        while ((line = br.readLine()) != null) {
            line = line.trim();
            if (line.contains("\"k\"")) {
                k = Integer.parseInt(line.split(":")[1].trim().replace(",", ""));
            }
            if (line.matches("\"\\d+\"\\s*:\\s*\\{")) {
                int x = Integer.parseInt(line.split("\"")[1]);
                String baseLine = br.readLine().trim();
                String valueLine = br.readLine().trim();
                int base = Integer.parseInt(baseLine.split(":")[1].trim().replace("\"", "").replace(",", ""));
                String value = valueLine.split(":")[1].trim().replace("\"", "").replace("}", "").replace(",", "");
                long y = baseToDecimal(value, base);
                roots.add(new Point(x, y));
            }
        }
        br.close();
        return roots.subList(0, k);  // return only k points
    }

    // Lagrange Interpolation to find f(0)
    public static long lagrangeInterpolation(List<Point> points) {
        double result = 0;
        int k = points.size();
        for (int j = 0; j < k; j++) {
            double term = points.get(j).y;
            for (int i = 0; i < k; i++) {
                if (i != j) {
                    term *= (0.0 - points.get(i).x) * 1.0 / (points.get(j).x - points.get(i).x);
                }
            }
            result += term;
        }
        return Math.round(result);  // since c is integer
    }

    public static void main(String[] args) throws Exception {
        // First test case
        List<Point> testcase1 = parseJsonRoots("testcase1.json", 3);
        long secret1 = lagrangeInterpolation(testcase1);

        // Second test case
        List<Point> testcase2 = parseJsonRoots("testcase2.json", 7);
        long secret2 = lagrangeInterpolation(testcase2);

        System.out.println("Secret for Testcase 1: " + secret1);
        System.out.println("Secret for Testcase 2: " + secret2);
    }
}
