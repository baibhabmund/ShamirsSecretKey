import java.util.List;

public class Main {
    public static void main(String[] args) throws Exception {
        List<SecretPolynomialSolver.Point> testcase1 = SecretPolynomialSolver.parseJsonRoots("src/input/testcase1.json", 3);
        long secret1 = SecretPolynomialSolver.lagrangeInterpolation(testcase1);

        List<SecretPolynomialSolver.Point> testcase2 = SecretPolynomialSolver.parseJsonRoots("src/input/testcase2.json", 7);
        long secret2 = SecretPolynomialSolver.lagrangeInterpolation(testcase2);

        System.out.println("Secret for Testcase 1: " + secret1);
        System.out.println("Secret for Testcase 2: " + secret2);
    }
}
